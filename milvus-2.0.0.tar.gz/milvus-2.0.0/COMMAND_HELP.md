# Commands to trigger jobs

## Guide

1. The job will be triggered when your comments on pull request matched command.

## Commands

|  Command                 |    Description                                                             |
| -------------------------|----------------------------------------------------------------------------|
|  /run-checks             |  Trigger Jenkins Job for e2e tests.                                         |
| rerun ut    |  Trigger failed github workflow jobs, including code checker & unit tests.  |
