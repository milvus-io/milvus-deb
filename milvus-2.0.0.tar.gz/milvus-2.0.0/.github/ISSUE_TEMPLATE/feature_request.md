---
name: "\U0001F680 Feature request"
about: As a user, I want to request a feature for Milvus
title: ''
labels: kind/feature
assignees: ''

---

<!-- Please state your issue using the following template and, most importantly, in English. -->
#### Is your feature request related to a problem? Please describe:


#### Describe the solution you'd like:


#### Describe alternatives you've considered:


#### Additional context:

